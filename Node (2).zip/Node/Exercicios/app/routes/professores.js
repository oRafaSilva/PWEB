module.exports = function(app){
app.get('/informacao/professores', function(req,res){
    // res.send("<html><body>Professores\ da Fatec Sorocaba</body></html>");
    // res.render("informacao/professores");

    const sql = require('mssql');

    const sqlConfig = {
        user: 'BD2313038',
        password: 'R@fael18',
        database: 'BD',
        server: 'apolo',
        options:{
            encrypt: false,
            trustServerCertificate: true,
        }
    }

    async function getProfessores() {
        try{
            const pool = await sql.connect(sqlConfig);

            const results = await pool.request().query('SELECT * from PROFESSORES')

            // res.json(results.recordset);
            res.render('informacao/professores',{profs:results.recordset})
        } catch(err){
            console.log(err)
        }
    }
    getProfessores();
});
}